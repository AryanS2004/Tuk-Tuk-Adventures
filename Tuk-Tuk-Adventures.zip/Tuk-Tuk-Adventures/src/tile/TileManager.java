package tile;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;

import main.GamePanel;
import main.UtilityTool;

public class TileManager 
{
	GamePanel gp;
	public Tile[] tile;
	public int mapTileNum[][];
	
	public TileManager(GamePanel gp)
	{
		this.gp = gp;
		tile = new Tile[50];
		mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
		
		getTileImage();
		loadMap("/maps/World01.txt");
	}
	
	public void getTileImage()
	{
			//PlACEHOLDERS
			setup(0, "Grass_Tile", false);
			setup(1, "Grass_Tile", false);
			setup(2, "Grass_Tile", false);
			setup(3, "Grass_Tile", false);
			setup(4, "Grass_Tile", false);
			setup(5, "Grass_Tile", false);
			setup(6, "Grass_Tile", false);
			setup(7, "Grass_Tile", false);
			setup(8, "Grass_Tile", false);
			setup(9, "Grass_Tile", false);
			
			//Main Tiles
			setup(10, "GrassN_Tile", false);
			setup(11, "Grass_Tile", false);
			setup(12, "Wall_Tile", true);
			setup(13, "Earth_Tile", false);
			setup(14, "Tree_Tile", true);
			setup(15, "Water_Top", true);
			setup(16, "Water_Top_Left", true);
			setup(17, "Water_Top_Right", true);
			setup(18, "Water_Right", true);
			setup(19, "Water_Left", true);
			setup(20, "Water_Down_Right", true);
			setup(21, "Water_Down_Left", true);
			setup(22, "Water_Back", true);
			setup(23, "Water_Tile", true);
			setup(24, "Dirt_Tile", false);
			setup(25, "Dirt_Top", true);
			setup(26, "Dirt_Top_Right", true);
			setup(27, "Dirt_Top_Left", true);
			setup(28, "Dirt_Right", true);
			setup(29, "Dirt_Left", true);
			setup(30, "Dirt_Down", true);
			setup(31, "Dirt_Down_Right", true);
			setup(32, "Dirt_Down_Left", true);
			setup(33, "Dirt_Cactus", true);
			setup(34, "Dirt_Top_Left1", true);
			setup(35, "Dirt_Top_Right1", true);
			setup(36, "Dirt_Down_Left1", true);
			setup(37, "Dirt_Down_Right1", true);
			setup(38, "Water_Top_Left1", true);
			setup(39, "Door_Tile", false);
	}
	
	public void setup(int index, String imageName , boolean collision)
	{
		UtilityTool uTool = new UtilityTool();
		try {
			tile[index] = new Tile();
			tile[index].image = ImageIO.read(getClass().getResourceAsStream("/tiles/" + imageName + ".png"));
			tile[index].image = uTool.scaleImage(tile[index].image, gp.tileSize, gp.tileSize);
			tile[index].collision = collision;
			
		}catch(IOException e){
			e.printStackTrace();
		}
		
	}
	
	public void loadMap(String filePath)
	{
		try 
		{
			InputStream is = getClass().getResourceAsStream(filePath);
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			
			while (col < gp.maxWorldCol && row < gp.maxWorldRow)
			{
				String line = br.readLine();
				
				while(col<gp.maxWorldCol)
				{
					String numbers[] = line.split(" ");
					
					int num = Integer.parseInt(numbers[col]);
					
					mapTileNum[col][row] = num;
					col++;
				}
				if(col == gp.maxWorldCol)
				{
					col = 0;
					row++;
				}
			}
			br.close();
		}
		catch(Exception e)
		{
			
		}
	}
	
	public void draw(Graphics2D g2)
	{
		int worldCol = 0;
		int worldRow = 0;
		
		
		while(worldCol < gp.maxWorldCol && worldRow < gp.maxWorldRow)
		{
			int tileNum = mapTileNum[worldCol][worldRow];
			
			int worldX = worldCol * gp.tileSize;
			int worldY = worldRow * gp.tileSize;
			int screenX = worldX - gp.player.worldX + gp.player.screenX;
			int screenY = worldY - gp.player.worldY + gp.player.screenY;
			
			if(worldX + gp.tileSize > gp.player.worldX - gp.player.screenX && worldX - gp.tileSize < gp.player.worldX + gp.player.screenX && 
			   worldY + gp.tileSize > gp.player.worldY - gp.player.screenY && worldY - gp.tileSize < gp.player.worldY + gp.player.screenY)
			{
				g2.drawImage(tile[tileNum].image, screenX, screenY, null);
			}
			worldCol++;
			
			if(worldCol == gp.maxWorldCol)
			{
				worldCol = 0;
				worldRow++;
				
			}
		}
	}
}









