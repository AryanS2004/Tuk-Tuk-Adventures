package main;

import java.awt.Rectangle;

public class EventRect extends Rectangle
{
	int eventRectDefaultX, eventRectDefaultY;
	boolean eventDone = false;
	
	
}
