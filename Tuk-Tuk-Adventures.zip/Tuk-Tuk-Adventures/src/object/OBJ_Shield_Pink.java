package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Shield_Pink extends Entity{

	public OBJ_Shield_Pink(GamePanel gp) {
		super(gp);
		type = type_shield;
		name = "Pink Laser Shield";
		down1 = setup("/objects/shield_pink",gp.tileSize , gp.tileSize);
		defenseValue = 2;
		description = "[" + name + "] \nA Durable Laser \nShield.";
	}

}
