package object;

import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_Heart extends Entity
{
	GamePanel gp;
	public OBJ_Heart(GamePanel gp)
	{
		super(gp);
		this.gp = gp;
		type = type_pickUpOnly;
		name = "Heart";
		value = 2;
		down1 = setup("/objects/Full_Heart" , gp.tileSize , gp.tileSize);
		image = setup("/objects/Full_Heart" , gp.tileSize , gp.tileSize);
		image2 = setup("/objects/Half_Heart" , gp.tileSize , gp.tileSize);
		image3 = setup("/objects/Empty_Heart" , gp.tileSize , gp.tileSize);
	}
	
	public void use(Entity entity)
	{
		gp.playSE(2);
		value = value-1;
		gp.ui.addMessage("Life + " + value );	
		value = value+1;
		entity.life += value;
	}
}
