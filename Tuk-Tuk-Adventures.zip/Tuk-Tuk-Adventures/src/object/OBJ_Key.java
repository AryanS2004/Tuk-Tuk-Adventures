package object;

import java.io.IOException;

import javax.imageio.ImageIO;

import entity.Entity;
import main.GamePanel;

public class OBJ_Key extends Entity
{
	GamePanel gp;
	
	public OBJ_Key(GamePanel gp)
	{
		super(gp);
		name = "Golden Key";
		down1 = setup("/objects/Key_Tile" , gp.tileSize , gp.tileSize);
		description = "[" + name + "] \nIt opens the Door.";
	}
}
