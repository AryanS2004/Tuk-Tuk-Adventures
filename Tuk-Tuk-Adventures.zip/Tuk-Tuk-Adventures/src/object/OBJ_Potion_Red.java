package object;

import entity.Entity;
import main.GamePanel;

public class OBJ_Potion_Red extends Entity
{
	GamePanel gp;
	public OBJ_Potion_Red(GamePanel gp) {
		super(gp);
		this.gp = gp;
		type = type_consumable;
		name = "Red Postion";
		value = 6;
		down1 = setup("/objects/potion_red" , gp.tileSize , gp.tileSize);
		description = "[" + name + "] \nHeals your Life by " + value + ".";
	}
	
	public void use(Entity entity)
	{
		gp.gameState = gp.dialogueState;
		value = value - 3;
		gp.ui.currentDialogue = "You Drink the " + name + "!\n" + "Your life has been recoverd by " + value + ".";
		value = value + 3;
		entity.life += value;
		if(gp.player.life > gp.player.maxLife)
		{
			gp.player.life = gp.player.maxLife;
		}
		gp.playSE(2);
	}

}
