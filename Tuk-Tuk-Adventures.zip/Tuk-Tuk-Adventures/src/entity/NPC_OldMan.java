package entity;

import java.util.Random;

import main.GamePanel;

public class NPC_OldMan extends Entity
{
	public NPC_OldMan(GamePanel gp)
	{
		super(gp);
		
		direction = "down";
		speed = 1;
		
		getImage();
		setDialouge();
	}
	
	public void getImage()
	{	
		up1 = setup("/npc/oldman_up_1" , gp.tileSize , gp.tileSize);
		up2 = setup("/npc/oldman_up_2" , gp.tileSize , gp.tileSize);
		down1 = setup("/npc/oldman_down_1" , gp.tileSize , gp.tileSize);
		down2 = setup("/npc/oldman_down_2" , gp.tileSize , gp.tileSize);
		left1 = setup("/npc/oldman_left_1" , gp.tileSize , gp.tileSize);
		left2 = setup("/npc/oldman_left_2" , gp.tileSize , gp.tileSize);
		right1 = setup("/npc/oldman_right_1" , gp.tileSize , gp.tileSize);
		right2 = setup("/npc/oldman_right_2" , gp.tileSize , gp.tileSize);
	}
	
	public void setDialouge()
	{
		dialouges[0] = "Hello , Young man!";
		dialouges[1] = "Welcome to the island where \nnothing is impossible.";
		dialouges[2] = "I used to be the magician of \nthis island...";
		dialouges[3] = "But now i am too old for those \ntrickes.";
		dialouges[4] = "Leave all this...";
		dialouges[5] = "So now that i look at you, \ni think you must have come here \nfor something...";
		dialouges[6] = "From the face of yours... \nyou seems to come here for \nthat only...";
		dialouges[7] = "The Treasure !!";
		dialouges[8] = "Well all i can say is there \nare many who have come for that \nin the past...";
		dialouges[9] = "But i have seen none leaving \nthis island with the treasure.";
		dialouges[10] = "Rumers says its a ancient treasure \nfrom the time of mythology !!";
		dialouges[11] = "But no one is sure cause \nno one has ever seen it...";
		dialouges[12] = "So i just want to say \nall the best for the adventure of your.";
	}
	
	public void setAction()
	{
		actionLookCounter ++;
		
		if(actionLookCounter == 100)
		{	
			Random random = new Random();
			int i = random.nextInt(100)+1; // Pick random number from 1 - 100
		
			if(i<= 25)
			{
				direction = "up";
			}
			if(i > 25 && i <= 50)
			{
				direction = "down";
			}
			if(i > 50 && i <= 75)
			{
				direction = "left";
			}
			if(i > 75 && i <= 100)
			{
				direction = "right";
			}
			
			actionLookCounter = 0;
		}
	}
	
	public void speak()
	{
		super.speak();
	}
}












